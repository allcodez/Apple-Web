# video-scroll
Very basic POC video scrub on scroll

Using live sass compile and gsap scroll trigger.
Video encoding matters!
